package com.example.democontrollerGETPOST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoControllerGetPostApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoControllerGetPostApplication.class, args);
	}

}
