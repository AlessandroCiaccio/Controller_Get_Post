package com.example.democontrollerGETPOST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoControllerGetPostApplicationTests {

	@Test
	void contextLoads() {
	}

}
